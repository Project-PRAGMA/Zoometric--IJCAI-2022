import numpy as np
import itertools

## Functions for checking if matrix X is a
## pairwise matrix of some elections (with 1 or 2 votes)

# Function that checks whether there is a row
# that corresponds to a top candidate in some vote and then removes that row
def remove_top(X,m):
  if (X.sum(axis=0)==0).sum()!=1:
    return(-1, X)
  else:
    k = np.where(X.sum(axis=0)==0)[0][0]
    X = np.hstack((X[:,:k],X[:,k+1:]))
  if X[k].sum()!=m-1:
    return(-1, X)
  else:
    X = np.vstack((X[:k,:],X[k+1:,:]))
  return(k, X)

# Function that checks whether matrix X can be realized as a 1 vote election
def is_vote(X):
  m = X.shape[0]
  vote = []
  for i in range(m-1):
    k, X = remove_top(X,m)
    if k == -1:
      return(False, vote)
    else:
      m = m-1
      vote.append(k)
  vote.append(0)
  for i in range(len(vote)-1,-1,-1):
    for j in range(i,len(vote)):
      if vote[j]>=vote[i]:
        vote[j]=vote[j]+1
  vote = [x-1 for x in vote]
  return(True, vote)

# Function that reutrns all rows that can correspond to top candidate in a vote
def all_tops_in(X,m):
  choice = np.where((X>0).sum(axis=1)==m-1)[0]
  if choice.shape[0] == 0:
    return([(-1,X)])
  else:
    result = []
    for k in choice:
      Y = np.hstack((X[:,:k],X[:,k+1:]))
      Y = np.vstack((Y[:k,:],Y[k+1:,:]))
      result.append((k,Y))
    return(result)

# Function that checks whether matrix X can be realized as a 2 vote elections
def is_elections_2(X):
  m = X.shape[0]
  next_options = [([],X)]
  for i in range(m-1):
    current_options = next_options
    next_options = []
    for vote, Y in current_options:
      options = all_tops_in(Y,m)
      if options[0][0]!=-1:
        for candidate, Z in options:
          next_options.append((vote + [candidate], Z))
    m = m-1
  results = []
  for vote, _ in next_options:
    vote.append(0)
    for i in range(len(vote)-1,-1,-1):
      for j in range(i,len(vote)):
        if vote[j]>=vote[i]:
          vote[j]=vote[j]+1
    vote = [x-1 for x in vote]
    Y = vote2matrix(vote)
    check, vote2 = is_vote(X-Y)
    if check:
      results.append([vote,vote2])
  return(results)

## Functions for constructing the pairwise matrix of given election

# Inversion of permutation
def invert_perm(vote):
  x = np.array(vote)
  return(np.argsort(x))

# Representing a vote as a matrix
def vote2matrix(vote):
  m = len(vote)
  x = invert_perm(vote)
  X = np.fromfunction(lambda i, j: x[i] < x[j], (m, m), dtype=int).astype(int)
  return(X)

# Representing elections as a matrix
def election2matrix(elections):
  m = len(elections[0])
  X = np.zeros((m,m),dtype=int)
  for vote in elections:
    X = X + vote2matrix(vote)
  return(X)

## Functions for calculating the distance between elections
## based on the pairwise matrices

# Pairwise distance for a fixed matching
def l1_on_matching(X,Y):
  return(np.abs(X-Y).sum())

# Tranformation of matrix for a given permutation of candidates
def m_permute(X, perm):
  Y = X[perm]
  Y = Y[:,perm]
  return(Y)

# Pairwise distance (returns distance and all optimal matchings)
  # permutations = True – returns permutations of optimal matchings
  # permutations = False – returns matrices of X in optimal matchings
def l1_distance(X,Y, permutations = False):
  m = X.shape[0]
  min = np.infty
  opt_matching_perms = []
  opt_matching_mats = []
  id_perm = list(range(m))
  for perm in itertools.permutations(id_perm):
    perm = list(perm)
    Z = m_permute(X, perm)
    dist = l1_on_matching(Z,Y)
    if dist < min:
      min = dist
      opt_matching_perms = [perm]
      opt_matching_mats = [Z]
    elif dist == min:
      opt_matching_perms.append(perm)
      opt_matching_mats.append(Z)
  if permutations:
    return(min, opt_matching_perms)
  else:
    return(min, opt_matching_mats)

## Functions for checking if there are elections
## in between given elections with 2 votes

# All matrices between two matrices for a fixed matching
# (including these two matrices)
def all_between(X,Y):
  Diff = Y-X
  m = Diff.shape[0]
  ZERO = np.zeros((m,m),dtype=int)
  one_dim_diffs = []
  volumes = []
  for i in range(m):
    for j in range(i-1):
      if Diff[i,j]!=0:
        volumes.append(abs(Diff[i,j]))
        Z = np.copy(ZERO)
        Z[i,j] = np.sign(Diff[i,j])
        Z[j,i] = np.sign(Diff[j,i])
        one_dim_diffs.append(Z)
  results = [X]
  for vol, diff in zip(volumes,one_dim_diffs):
    results_past = results
    results = []
    for Z in results_past:
      for i in range(vol+1):
        results.append(Z + diff*i)
  return(results)

# Checking if matrices between two matrices are realizable as 2 vote elections
def check_in_between_on_fixed_matching(X,Y):
  betweens = all_between(X,Y)
  realizable = []
  for Z in betweens:
    if len(is_elections_2(Z))>0:
      realizable.append(True)
    else:
      realizable.append(False)
  return(realizable)

# Checking if there is a realizable matrix between two elections
# (for all possible matchings)
def check_in_between(el1,el2):
  print("Checking elections:")
  print(el1)
  print("and")
  print(el2)
  X = election2matrix(el1)
  Y = election2matrix(el2)
  dist, all_matchings = l1_distance(X,Y)
  print("Pairwise distance " + str(dist) + " with " + str(len(all_matchings)) + " optimal matchings.")
  for i, Z in enumerate(all_matchings):
    print("Checking matching no. " + str(i+1))
    checks = check_in_between_on_fixed_matching(Z,Y)
    print(checks)
    if any(checks[1:-1]):
      print("Found an election in between.")
      return(False)
    else:
      print("No elections in between.")
  print("There are no elections in between provided elections.")
  print("Counterexample confirmed.")
  return(True)

## Execution – verification of the counterexample

# Election 1
# v1 : a > b > c > d > e > f > g
# v2 : e > b > g > d > a > f > c

el1 = [[0,1,2,3,4,5,6],[4,1,6,3,0,5,2]]

# Election 2
# v1 : a > b > c > g > d > e > f
# v2 : e > b > d > a > f > g > c

el2 = [[0,1,2,6,3,4,5],[4,1,3,0,5,6,2]]

# Verify the counterexample

is_counterexample = not(check_in_between(el1,el2))
