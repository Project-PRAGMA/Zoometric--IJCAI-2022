#include<stdio.h>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <utility>
#include <ctime>
#include <unistd.h>
#include <random>


using namespace std;

#define MY_TYPE string
#define num_candidates 4
#define num_voters 4

#define BIG 100000
typedef int row;
#define ROW_TYPE INT
typedef int col;
#define COL_TYPE INT
typedef int cost;
#define COST_TYPE INT
#if !defined TRUE
#define	 TRUE		1
#endif
#if !defined FALSE
#define  FALSE		0
#endif
typedef int boolean;


vector<std::vector<int> > ALL_PERMS;


void print_election(vector<vector<int>> e1){
    for(int i=0; i<num_voters; i++){
        for(int j=0;j<num_candidates;j++){
            cout<<e1[i][j];
        }
        cout<<endl;
    }
}

void print_vector(std::vector<int> vec){
    for(int i=0;i<num_candidates;i++){
        cout << vec[i] << ' ';
    } cout << endl;
}


inline int bordawise_is_zero(pair<std::vector<std::vector<int> >,std::vector<std::vector<int> > > elp) {
    std::vector<std::vector<int> > e1 = std::get<0>(elp);
    std::vector<std::vector<int> > e2 = std::get<1>(elp);

    std::vector<int> borda_scores_1 = {0,0,0,0};
    std::vector<int> borda_scores_2 = {0,0,0,0};
    for(int i=0;i<num_voters;i++){
        for(int j=0;j<num_candidates;j++) {
            borda_scores_1[e1[i][j]] += num_candidates-j-1;
            borda_scores_2[e2[i][j]] += num_candidates-j-1;
        }
    }
    std::sort (borda_scores_1.begin(), borda_scores_1.end());
    std::sort (borda_scores_2.begin(), borda_scores_2.end());

    for(int i=0;i<num_voters;i++){
        if (borda_scores_1[i] != borda_scores_2[i]) return false;
    }
    return true;
}

std::vector<int> LONG_BORDA_SCORES_1 = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0};
std::vector<int> LONG_BORDA_SCORES_2 = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0};

inline int bordawise_is_zero2(pair<std::vector<std::vector<int> >,std::vector<std::vector<int> > > elp) {
    std::vector<std::vector<int> > e1 = std::get<0>(elp);
    std::vector<std::vector<int> > e2 = std::get<1>(elp);

    std::vector<int> borda_scores_1 = {0,0,0,0};
    std::vector<int> borda_scores_2 = {0,0,0,0};
    for(int i=0;i<num_voters;i++) {
        for (int j = 0; j < num_candidates; j++) {
            borda_scores_1[e1[i][j]] += num_candidates - j - 1;
            borda_scores_2[e2[i][j]] += num_candidates - j - 1;
        }
    }
    for(int i=0;i<num_candidates;i++) {
        LONG_BORDA_SCORES_1[borda_scores_1[i]] += 1;
        LONG_BORDA_SCORES_2[borda_scores_2[i]] += 1;
    }
    for(int i=0;i<num_candidates;i++){
        int id = borda_scores_1[i];

        if (LONG_BORDA_SCORES_1[id] != LONG_BORDA_SCORES_2[id]){
            for(int j=0;j<num_candidates;j++){
                LONG_BORDA_SCORES_1[borda_scores_1[j]] = 0;
                LONG_BORDA_SCORES_2[borda_scores_2[j]] = 0;
            }
            return false;
        }
    }
    for(int j=0;j<num_candidates;j++){
        LONG_BORDA_SCORES_1[borda_scores_1[j]] = 0;
        LONG_BORDA_SCORES_2[borda_scores_2[j]] = 0;
    }
    return true;
}


inline bool check(vector<vector<int> > e1, vector<vector<int> > e2, int k){

    vector<int> voter_perm = ALL_PERMS[k];
    vector<int> cand_perm = e2[voter_perm[0]];

    for(int i=1;i<num_voters;i++){
        vector<int> v1 = e1[i];
        vector<int> v2 = e2[voter_perm[i]];

        for(int j=0;j<num_candidates;j++){
            if(cand_perm[v1[j]] != v2[j]) {
                return false;
            }
        }
    }

    return true;
}

inline bool isomorphic(pair<std::vector<std::vector<int> >,std::vector<std::vector<int> > > elp){
    vector<vector<int> > e1 = get<0>(elp);
    vector<vector<int> > e2 = get<1>(elp);

    int factorial = 24;

    for(int k=0;k<factorial;k++){
        if(check(e1, e2, k)) return true;
    }

    return false;
}





inline string vote_to_string(std::vector<int> vote){
    string output = "";
    for(int i=0; i<num_candidates; i++){
        output += to_string(vote[i]);
    }
    return output;
}


inline MY_TYPE convert_election(std::vector<std::vector<int> > election){
    string output = "";
    for(int i=0; i<num_voters; i++){
        output += vote_to_string(election[i]);
    }

    return output;
}

inline bool my_sort(vector<int> v1, vector<int> v2){
 return vote_to_string(v1) < vote_to_string(v2);
}

int main(int argc, char* argv[]) {



    int distance;
    string exp = "4x4";
    std::vector<int> v = {0,1,2,3};
    int factorial = 24;

    for(int i=0;i<factorial;i++){
        ALL_PERMS.push_back(v);
        next_permutation(v.begin(), v.end());
    }

    std::vector<std::vector<std::vector<int> > > all_elections = {};
    std::vector<string> all_string_elections = {};
    std::vector<MY_TYPE> all_converted_elections = {};

    std::vector<std::vector<int> > new_election;

    new_election.push_back({0,1,2,3});
    new_election.push_back({0,1,2,3});
    new_election.push_back({0,1,2,3});
    new_election.push_back({0,1,2,3});


    int fast_ctr = 0;
    int slow_ctr = 0;
    for (int i1=0; i1 < factorial; i1++){

        for (int i2=0; i2 < factorial; i2++) {

            for (int i3=0; i3 < factorial; i3++) {
                fast_ctr++;
                if(i1 <= i2 and i2 <= i3){
                    slow_ctr++;
                }

            }
        }
        cout << slow_ctr << ' ' << fast_ctr << endl;
    }


    int ctr = 0;
    int tmp_ctr = 0;
    for (int i1=0; i1 < factorial; i1++){
        new_election[1] = ALL_PERMS[i1];
        for (int i2=i1; i2 < factorial; i2++) {

            new_election[2] = ALL_PERMS[i2];
            for (int i3=i2; i3 < factorial; i3++) {

                new_election[3] = ALL_PERMS[i3];


                    vector<vector<int>> copy_election = new_election;


                    bool unique = true;
                    if (unique){
                        for (auto const &tmp_election: all_elections) {


                            pair<std::vector<std::vector<int> >, std::vector<std::vector<int> > > my_pair(tmp_election,
                                                                                                          copy_election);

                            if (bordawise_is_zero2(my_pair)) {

                                if (isomorphic(my_pair)) {
                                    unique = false;
                                    break;
                                }
                            }
                        }

                        if (unique) {
                            all_elections.push_back(copy_election);

                            string path = "./experiments/" + exp + "/elections/all_" + to_string(ctr) + ".soc";
                            ofstream myfile;
                            myfile.open(path);

                            myfile << "# All {'ctr': " << ctr << "}" << endl;
                            myfile << num_candidates << endl;
                            for (int cand = 0; cand < num_candidates; cand++) {
                                myfile << to_string(cand) << ", c" << to_string(cand) << endl;
                            }
                            myfile << to_string(num_voters) << ", " << to_string(num_voters) << ", " << to_string(num_voters) << endl;
                            for (int vote = 0; vote < num_voters; vote++) {
                                myfile << "1";
                                for (int cand = 0; cand < num_candidates; cand++) {
                                    myfile << ", " << to_string(new_election[vote][cand]);
                                }
                                myfile << endl;
                            }

                            myfile.close();

                            ctr++;

                        }
                    }

                    tmp_ctr++;

                    if(tmp_ctr%100 == 0) {
                        cout << ctr << "   " << tmp_ctr << endl;
                    }

            }
        }

    }

    return 0;
}


