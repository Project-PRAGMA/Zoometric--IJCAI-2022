"Understanding Distance Measures Among Elections?"
# 4574
====================================================================

It suffices to run main_mini.py to get the final results:
python main_mini.py

'Experiments' folder contains all the needed data.

====================================================================

To repeat all the experiments from the very beginning
it requires installation of a large number of packages.

To repeat full experiment, first run:
python main_full_part_1.py

compile main_swap file:
g++ -std=c++2a -o main_swap.out main_swap.cpp

run main_swap file:
./main_swap.out 0 1 zoometric_10x50_fake 344 10 50 swap

compile post file:
g++ -std=c++2a -o post.out post.cpp

run post file:
./post.out 1 zoometric_10x50_fake 344 swap

compile all_elections_... files:
g++ -std=c++2a -o all_elections_3x3.out all_elections_3x3.cpp
g++ -std=c++2a -o all_elections_3x4.out all_elections_3x4.cpp
g++ -std=c++2a -o all_elections_3x5.out all_elections_3x5.cpp
g++ -std=c++2a -o all_elections_4x3.out all_elections_4x3.cpp
g++ -std=c++2a -o all_elections_4x4.out all_elections_4x4.cpp
g++ -std=c++2a -o all_elections_4x5.out all_elections_4x5.cpp

run all_elections_... files:
./all_elections_3x3.out
./all_elections_3x4.out
./all_elections_3x5.out
./all_elections_4x3.out
./all_elections_4x4.out
./all_elections_4x5.out

run python file:
python main_full_part_2.py

====================================================================

To verify counterexample for pairwise intrinsicness run:
python intrinsic_pairwise.py