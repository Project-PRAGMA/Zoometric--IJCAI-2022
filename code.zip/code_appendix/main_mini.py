
import mapel
import matplotlib.pyplot as plt
import itertools

from scipy.stats import stats


if __name__ == "__main__":

    experiment_id = 'zoometric_10x50_fake'
    instance_type = 'ordinal'
    distance_ids = [
        'emd-bordawise',
        'emd-positionwise',
        'l1-positionwise',
        'l1-pairwise',
        'swap',
        'discrete'
    ]

    for distance_id in distance_ids:
        print(distance_id)

        experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                              instance_type=instance_type,
                                              clean=False,
                                              distance_id=distance_id)

        experiment.print_map(adjust=True,
                             legend=False,
                             shading=True, saveas=f'raw_maps/{distance_id}_10x50',
                             textual=['ID', 'UN', 'AN', 'ST']
                             )

    # COMPARE METRICS (part 1/2)

    experiment_id = 'zoometric_10x50_fake'
    num_voters = 50

    names = [
        'swap',
        'emd-positionwise',
        'l1-positionwise',
        'l1-pairwise',
        'emd-bordawise',
        'discrete'
    ]
    multiplayer = {
        'swap': 1,
        'swap_bf': 1,
        'emd-positionwise': num_voters,
        'emd-pos_swap': 1,
        'l1-positionwise': num_voters,
        'l1-pairwise': num_voters,
        'emd-bordawise': 1,
        'discrete': 1
    }

    all_distances = {}

    ctr = 0
    for name in names:
        print(name)
        experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                              instance_type='ordinal', distance_id=name)

        all_distances[name] = experiment.distances

    line = ""

    fam_names = list(experiment.families.keys())
    print(fam_names)

    print("=======")

    output = {f: '' for f in fam_names}

    for name_1, name_2 in itertools.combinations(names, 2):
        if ctr >= 5:
            break
        print(name_1, name_2)
        ctr += 1

        empty_x = []
        empty_y = []

        values_x = []
        values_y = []
        for f in fam_names:
            for e1, e2 in itertools.combinations(all_distances[name_1], 2):
                if f in e1 and f in e2:
                    values_x.append(all_distances[name_1][e1][e2] * multiplayer[name_1])
                    values_y.append(all_distances[name_2][e1][e2] * multiplayer[name_2])

            pear = round(stats.pearsonr(values_x, values_y)[0], 3)
            pear_text = f'PCC = {pear}'
            output[f] += f' & {pear}'


    for f in output:
        print(f, output[f], "\\\\")


    # COMPARE METRICS (part 2/2)

    experiment_id = 'zoometric_10x50_fake'
    num_voters = 50


    names = [
        'swap',
        'emd-positionwise',
        'l1-positionwise',
        'l1-pairwise',
        'emd-bordawise',
        'discrete'
    ]
    multiplayer = {
        'swap': 1,
        'swap_bf': 1,
        'emd-positionwise': num_voters,
        'emd-pos_swap': 1,
        'l1-positionwise': num_voters,
        'l1-pairwise': num_voters,
        'emd-bordawise': 1,
        'discrete': 1
    }

    all_distances = {}

    ctr = 0
    for name in names:
        print(name)
        experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                              instance_type='ordinal', distance_id=name)
        all_distances[name] = experiment.distances

    print("=======")
    for name_1, name_2 in itertools.combinations(names, 2):
        if ctr >= 5:
            break
        ctr += 1

        values_x = []
        values_y = []
        empty_x = []
        empty_y = []
        for e1, e2 in itertools.combinations(all_distances[name_1], 2):
            if e1 in ['AN', 'UN', 'ID', 'ST'] or e2 in ['AN', 'UN', 'ID', 'ST']:
                empty_x.append(all_distances[name_1][e1][e2] / num_voters)
                empty_y.append(all_distances[name_2][e1][e2])
            else:
                values_x.append(all_distances[name_1][e1][e2] / num_voters)
                values_y.append(all_distances[name_2][e1][e2])

        fig = plt.figure()
        ax = fig.add_subplot()

        ax.scatter(values_x, values_y, s=4, alpha=0.02, color='purple')

        pear = round(stats.pearsonr(values_x, values_y)[0], 3)
        pear_text = f'PCC = {pear}'
        print('pear', pear)
        plt.text(0.7, 0.1, pear_text, transform=ax.transAxes, size=14)

        plt.xlabel(name_1, size=20)
        plt.ylabel(name_2, size=20)
        title = f'm=10 n=50'
        plt.title(title, size=24)
        saveas = f'images/correlation/corr_{name_1}_{name_2}'
        plt.savefig(saveas, bbox_inches='tight')
        plt.show()


    # EQUIVALENCE CLASSES

    experiment_id = 'eq_classes/3x3'
    num_voters = 3

    names = [
        'swap_bf',
        'emd-positionwise',
        'l1-positionwise',
        'l1-pairwise',
        'emd-bordawise',
        'discrete'
    ]
    multiplayer = {
        'swap': 1,
        'swap_bf': 1,
        'emd-positionwise': num_voters,
        'emd-pos_swap': 1,
        'l1-positionwise': num_voters,
        'l1-pairwise': num_voters,
        'emd-bordawise': 1,
        'discrete': 1
    }

    all_distances = {}

    ctr = 0
    for name in names:
        print(name)
        experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                              instance_type='ordinal', distance_id=name)
        all_distances[name] = experiment.distances

    line = ""

    print("=======")
    for name_1, name_2 in itertools.combinations(names, 2):
        if ctr >= 5:
            break
        print(name_1, name_2)

        ctr += 1

        values_x = []
        values_y = []
        empty_x = []
        empty_y = []
        for e1, e2 in itertools.combinations(all_distances[name_1], 2):
            if e1 in ['AN', 'UN', 'ID', 'ST'] or e2 in ['AN', 'UN', 'ID', 'ST']:
                empty_x.append(all_distances[name_1][e1][e2] / num_voters)
                empty_y.append(all_distances[name_2][e1][e2])
            else:
                values_x.append(all_distances[name_1][e1][e2] / num_voters)
                values_y.append(all_distances[name_2][e1][e2])

        pear = round(stats.pearsonr(values_x, values_y)[0], 3)
        pear_text = f'PCC = {pear}'
        print('PCC', pear)
