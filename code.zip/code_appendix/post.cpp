#include <iostream>
#include <stdlib.h>
#include <string>
#include <fstream>
using namespace std;

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cout << "Arguments missing" << endl;
        return 0;
    }
    int number_threads = strtol(argv[1], nullptr, 0);
    string exp = argv[2];
    int e = strtol(argv[3], nullptr, 0);
    string modus = argv[4];

    int len = 0;
    for (int i = 0; i < e; i++) {
        for (int j = i + 1; j < e; j++) {
            len = len + 1;
        }
    }


    string path = "./experiments/" + exp + "/distances/" + modus + ".csv";
    ofstream myfile;
    myfile.open(path);
    myfile << "election_id_1;election_id_2;distance;time" << endl;
    for (int i = 0; i < number_threads; i++) {
        path = "./experiments/" + exp + "/distances/" + modus + "_" + to_string(i) + "_" +
               to_string(number_threads) + ".txt";
        ifstream myfileI(path);
        myfile << myfileI.rdbuf();
        myfileI.close();
    }
    myfile.close();


    return 0;
}