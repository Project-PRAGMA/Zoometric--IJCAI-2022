
import mapel
import matplotlib.pyplot as plt
import itertools

from scipy.stats import stats


if __name__ == "__main__":

    experiment_id = 'zoometric_10x50_fake'
    instance_type = 'ordinal'
    distance_ids = [
        'emd-bordawise',
        'emd-positionwise',
        'l1-positionwise',
        'l1-pairwise',
        'swap',
        'discrete'
    ]

    for distance_id in distance_ids:
        print(distance_id)

        experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                              instance_type=instance_type,
                                              clean=False,
                                              distance_id=distance_id)
        experiment.prepare_elections()